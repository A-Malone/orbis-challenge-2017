import sys

PLAYER_AI_PATH = sys.path[0]
LOCAL_PLAYER_UUID = "UNKNOWN_PLAYER"
MAP_NAME = ""
